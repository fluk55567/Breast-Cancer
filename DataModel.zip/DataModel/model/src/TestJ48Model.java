import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import weka.classifiers.trees.J48;
import weka.core.Instances;



public class TestJ48Model extends JFrame implements ActionListener {
    private final JTextField AgeField;
    private final JTextField BMIField;
    private final JTextField GlucoseField;
    private final JTextField InsulinField;
    private final JTextField HOMAField;
    private final JTextField LeptinField;
    private final JTextField AdiponectinField;
    private final JTextField ResistinField;
    private final JTextField MCPField;
    private final JLabel resultLabel;
    private final JButton classifyButton;

    public TestJ48Model() throws Exception {
        setTitle("Breast Cancer");
        setSize(450,300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        
        
        setVisible(true);

        //Add font
        Font modernFont = new Font("Montserrat", Font.PLAIN, 14);
        // Create the GUI components
        AgeField = new JTextField(6);
        AgeField.setFont(modernFont);

        BMIField = new JTextField(6);
        BMIField.setFont(modernFont);

        GlucoseField = new JTextField(6);
        GlucoseField.setFont(modernFont);
        InsulinField = new JTextField(6);
        InsulinField.setFont(modernFont);
        HOMAField = new JTextField(6);
        HOMAField.setFont(modernFont);
        LeptinField = new JTextField(6);
        LeptinField.setFont(modernFont);
        AdiponectinField = new JTextField(6);
        AdiponectinField.setFont(modernFont);
        ResistinField = new JTextField(6);
        ResistinField.setFont(modernFont);
        MCPField = new JTextField(6);
        MCPField.setFont(modernFont);

        resultLabel = new JLabel();
        
        Color buttonColor = new Color(102, 204, 255);

        classifyButton = new JButton("Classify");
        classifyButton.addActionListener(this);
        classifyButton.setForeground(Color.gray);
        classifyButton.setBackground(buttonColor);
        classifyButton.setFont(modernFont);
        classifyButton.setBorderPainted(true);

        // Add the GUI components to a panel
        JPanel panel = new JPanel(new GridLayout(13, 1));
        panel.setBackground(new Color(252,229,205));
        panel.add(new JLabel("Age: "));
        panel.add(AgeField);
        
        panel.add(new JLabel("BMI: "));
        panel.add(BMIField);
        panel.add(new JLabel("Glucose: "));
        panel.add(GlucoseField);
        panel.add(new JLabel("Insulin: "));
        panel.add(InsulinField);
        panel.add(new JLabel("HOMA: "));
        panel.add(HOMAField);
        panel.add(new JLabel("Leptin: "));
        panel.add(LeptinField);
        panel.add(new JLabel("Adiponectin: "));
        panel.add(AdiponectinField);
        panel.add(new JLabel("Resistin: "));
        panel.add(ResistinField);

        panel.add(new JLabel("MCP.1: "));
        panel.add(MCPField);

        /*panel.add(new JLabel(""));
        panel.add(MCPField);*/

        

        panel.add(new JLabel("Result: "));
        panel.add(resultLabel);

        panel.add(new JLabel(""));
        panel.add(classifyButton);

       
        panel.add(new JLabel("1=Healthy controls"));
        panel.add(new JLabel("\n"));
        panel.add(new JLabel("2=Patients"));


        

        // Add the panel to the frame and show the GUI
        getContentPane().add(panel, BorderLayout.CENTER);
        pack();
        setVisible(true);
    }

    public static void main(String[] args) throws Exception {
        new TestJ48Model();
    }

    public void actionPerformed(ActionEvent event) {
        try {
            // Get the user input values
            double Age = Double.parseDouble(AgeField.getText());
            double BMI = Double.parseDouble(BMIField.getText());
            double Glucose = Double.parseDouble(GlucoseField.getText());
            double Insulin = Double.parseDouble(InsulinField.getText());
            double HOMA = Double.parseDouble(HOMAField.getText());
            double Leptin = Double.parseDouble(LeptinField.getText());
            double Adiponectin = Double.parseDouble(AdiponectinField.getText());
            double Resistin = Double.parseDouble(ResistinField.getText());
            double MCP = Double.parseDouble(MCPField.getText());

            // Load the ARFF dataset
            BufferedReader reader = new BufferedReader(new FileReader("arff/dataR2.arff"));
            Instances data = new Instances(reader);
            reader.close();

            // Set the class index to the last attribute (class)
            data.setClassIndex(data.numAttributes() - 1);

            // Load the J48 model from file
            J48 model = (J48) weka.core.SerializationHelper.read("modelfinish/treedata.model");
            // Create an instance with the user input values
            weka.core.Instance instance = new weka.core.DenseInstance(data.numAttributes());
            instance.setValue(0, Age);
            instance.setValue(1, BMI);
            instance.setValue(2, Glucose);
            instance.setValue(3, Insulin);
            instance.setValue(4, HOMA);
            instance.setValue(5, Leptin);
            instance.setValue(6, Adiponectin);
            instance.setValue(7, Resistin);
            instance.setValue(8, MCP);

            instance.setDataset(data);

            // Classify the instance
            double result = model.classifyInstance(instance);

            // Set the result label to the predicted class value
            resultLabel.setText(data.classAttribute().value((int)result));
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}